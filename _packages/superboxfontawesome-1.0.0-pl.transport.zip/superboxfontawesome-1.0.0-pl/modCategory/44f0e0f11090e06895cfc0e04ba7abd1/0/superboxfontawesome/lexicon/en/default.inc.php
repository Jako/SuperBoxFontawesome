<?php
$_lang['superboxfontawesome.fontawesome'] = 'FontAwesome Icons';


