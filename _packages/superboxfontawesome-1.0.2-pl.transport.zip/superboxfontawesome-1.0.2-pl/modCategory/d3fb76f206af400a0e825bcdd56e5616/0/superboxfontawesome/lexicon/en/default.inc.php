<?php
/**
 * Default Lexicon Entries for SuperBoxFontawesome
 *
 * @package superboxfontawesome
 * @subpackage lexicon
 */

$_lang['superboxfontawesome.fontawesome'] = 'FontAwesome Icons';


