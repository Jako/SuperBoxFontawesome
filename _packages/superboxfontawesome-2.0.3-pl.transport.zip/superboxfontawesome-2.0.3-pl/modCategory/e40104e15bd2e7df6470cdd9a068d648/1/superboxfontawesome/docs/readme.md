# SuperBoxFontawesome

Select FontAwesome Icons in SuperBoxSelect

## Features

This MODX Extra displays a selectable list of FontAwesome Icons in the
SuperBoxSelect MODX Extra (https://modx.com/extras/package/superboxselect).

## Installation

MODX Package Management

## Usage

- Install the Package via MODX Package Manager.
- Edit a SuperBoxSelect template variable and the Type `FontAwesome Icons` is available.

## GitHub Repository

https://github.com/Jako/SuperBoxFontawesome
