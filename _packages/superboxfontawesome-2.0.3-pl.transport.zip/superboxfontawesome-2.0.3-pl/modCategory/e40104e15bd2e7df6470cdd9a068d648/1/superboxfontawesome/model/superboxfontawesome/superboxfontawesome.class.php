<?php
/**
 * SuperBoxFontawesome
 *
 * Copyright 2016-2023 by Thomas Jakobi <office@treehillstudio.com>
 *
 * @package superboxfontawesome
 * @subpackage classfile
 */

require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

/**
 * Class SuperBoxFontawesome
 */
class SuperBoxFontawesome extends \TreehillStudio\SuperBoxFontawesome\SuperBoxFontawesome
{
}
